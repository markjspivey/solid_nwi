const FOAF = $rdf.Namespace('http://xmlns.com/foaf/0.1/');
const nwi = $rdf.Namespace('https://markjspivey.github.io/nwi/nwi.ttl#');

// Log the user in and out on click
const popupUri = 'popup.html';
$('#login  button').click(() => solid.auth.popupLogin({ popupUri }));
$('#logout button').click(() => solid.auth.logout());

var store;
var fetcher;
var person;
var data;
var source;
var target;
var sourceSource;
var targetTarget;
var chain;
var chainSS;
var chainTT;

// Update components to match the user's login status
solid.auth.trackSession(session => {
  const loggedIn = !!session;
  $('#login').toggle(!loggedIn);
  $('#logout').toggle(loggedIn);
  if (loggedIn) {
    $('#user').text(session.webId);
    // Use the user's WebID as default profile
    if (!$('#thing').val())
      $('#thing').val(session.webId);
  }
});

$('#view').click(async function loadThing() {
  // Set up a local data store and associated data fetcher
  store = $rdf.graph();
  fetcher = new $rdf.Fetcher(store);

  // Load the person's data into the store
  person = $('#thing').val();
  await fetcher.load(person);

  // Display their details
  data = store.any($rdf.sym(person), nwi('hasData'));
  $('#data').empty();
  $('#data').text(data && data.value);

  // Display their details
  source = store.any($rdf.sym(person), nwi('hasSource'));
  $('#source').empty();
  $('#source').append(
              $('<a>').text(source && source.value)
                      .click(() => $('#thing').val(source.value))
                      .click(loadThing));

  // Display their details
  target = store.any($rdf.sym(person), nwi('hasTarget'));
  $('#target').empty();
  $('#target').append(
              $('<a>').text(target && target.value)
                      .click(() => $('#thing').val(target.value))
                      .click(loadThing));

  async function loadSourceSource() {
    // Display their details
    sourceSource = source;
    await fetcher.load(sourceSource);
  }

  loadSourceSource();
  
  chainSS = store.any($rdf.sym(sourceSource), nwi('hasData'));
//}

//async function loadTargetTarget() {

  // Display their details
  targetTarget = target;
  await fetcher.load(targetTarget);
  
  chainTT = store.any($rdf.sym(targetTarget), nwi('hasData'));
//}

//  loadTargetTarget();

  $('#chain').empty();
  $('#chain').text((chainSS && chainSS.value)+" "+(chainTT && chainTT.value));
});

